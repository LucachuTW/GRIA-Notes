# Output "I love Ruby"
say = "I love Ruby"; puts say

# Output "I *LOVE* RUBY"
say['love'] = "*love*"; puts say.upcase

# Output "I *love* Ruby", 5 times
5.times { puts say }

