console.log("process.uptime   = ", global.process.uptime());
console.log("process.title    = ", global.process.title);
console.log("process version  = ", global.process.version);
console.log("process.platform = ", global.process.platform);
console.log("process.cwd      = ", global.process.cwd());
console.log("process.uptime   = ", global.process.uptime());
